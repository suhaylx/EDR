# TuranSec engineering candidate

Read [the complete installation and rollback manual](docs/INSTALLATION.md).

Linux: use the separately invoked [service installer](docs/LINUX_SERVICE_INSTALLATION.md) after package verification and host approval. Building/extracting this archive never starts services.

Unsigned candidates require an independently checked manifest digest and explicit lab staging. No archive grants deployment authorization.
